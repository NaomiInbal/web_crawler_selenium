Muvan - Take Home Assignment

Authored by :Naomi Inbal - Weinstein

==Program Files==
login.html, main.html, test.csv, web_crawler.py

==Input==
.The user has to press enter to finish the execution

==Output==
Download the test.csv file
When the software finished its prints "Finished!"

==Prerequisites==
 Python3
pip

==Required libraries==
pip install -r requirements.txt


==How to run==
py  ./web_crawler.py


